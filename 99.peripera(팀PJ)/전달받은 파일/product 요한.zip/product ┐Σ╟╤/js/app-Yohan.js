const menu = [


      {
      id: 1,
      title: "잉크 무도 글로이 밤",
      category: "립",
      price: 13000,
      img: "./images/images-Yohan/잉크무드글로이밤.jpg",
      desc: `입술에 단비가 스며든 듯, 촉촉 쫀쫀 글로이 밤 
      <br> 투명하고 맑은 광감으로 생기 한 톤 UP 
      <br> 맘껏 바를 수 있는 비건 잉크 무드 글로이 밤을 만나보세요.`,
    },
  {
    id: 2,
    title: "[재입고] 잉크 무드 글로이 틴트",
    category: "립",
    price: 11000,
    img: "./images/images-Yohan/무드글로이틴트.jpg",
    desc: `페리페라 만의 글로시함을 다채롭게 담은 
    <br> 싱그러운 무드로 물든 청초 광택 틴트
    <br>잉크 무드 글로이 틴트`,
  },
  {
    id: 3,
    title: "잉크 무드 글로이 틴트#최고심콜라보",
    category: "립",
    price: 11000,
    img: "./images/images-Yohan/최고심콜라보.jpg",
    desc: `무기력하고 지친 페리 덕후들을 위해 준비한
    <br> 페리페라X최고심 갓생 프로젝트에 초대합니다!`,
  },
  {
    id: 4,
    title: "잉크 더 벨벳",
    category: "립",
    price: 10000,
    img: "./images/images-Yohan/잉크더벨벳.jpg",
    desc: `잉크처럼 선명한 컬러로 오랜 시간 유지
    <br> 컬러 하나 하나 뚜렷한 존재감! 
    <br> 잉크의 페리페라 잉크 더 벨벳`,
  },
  {
    id: 5,
    title: "재유Pick♥ 잉크 더 벨벳 #누디브루",
    category: "립",
    price: 10000,
    img: "./images/images-Yohan/재유Pick.jpg",
    desc: `누디한 얼그레이 색감을 우려낸 듯,
    <br>얼그레이시한 누드 컬러감이 은은하게 입혀진 누드브루잉 컬러`,
  },
  {
    id: 6,
    title: "잉크 더 에어리 벨벳",
    category: "립",
    price: 10000,
    img: "./images/images-Yohan/잉크더에어리벨벳.jpg",
    desc: `잉 크더 에어리 벨벳
    <br>5,810,859개
    <br>누적 판매 달성
    <br>틴트하면 페리페라 잉크틴트 에어리 벨벳`,
  },
  {
    id: 7,
    title: "잉크 무드 매트 스틱",
    category: "립",
    price: 14000,
    img: "./images/images-Yohan/잉크무드매트스틱.jpg",
    desc: `데굴데굴 가을 속으로
    <br>떨어지는 무르익은 도토리 컬렉션
    <br>페리페라의 가을 컬러 놓치지 마세요 :) `,
  },
  {
    id: 8,
    title: "잉크 벨벳 인텐스 스틱",
    category: "립",
    price: 11000,
    img: "./images/images-Yohan/잉크벨벳인텐스스틱.jpg",
    desc: `한 번만 터치해도 착! 달라부터
    <br>잉크를 담은 선명한 발색을 오래오래 `,
  },
  {
    id: 9,
    title: "잉크 글래스팅 립글로스",
    category: "립",
    price: 12000,
    img: "./images/images-Yohan/잉크글래스팅립글로스.jpg",
    desc: `잉크의 선명한 컬러감을 그대로 담은
    <br>비건 포뮬러 잉크 글래스팅 립글로즈
    <br>프랑스 이브  비건기관으로 부터
    <br>인증을 획득한 비건 제품입니다.`,
  },
  {
    id: 10,
    title: "심플레인 워터 블러 틴트",
    category: "립",
    price: 13000,
    img: "./images/images-Yohan/심플레인워터블러틴드.jpg",
    desc: `옷장 한 켠에 숨어든 빈티지 니팅(VINTAGE KNITTING)컬러무드로
    <br>당신만의 취향을 담아보세요`,
  },














  {
    id: 11,
    title: "올테이크 팔레트 14호",
    category: "아이",
    price: 21000,
    img: "./images/images-Yohan/올테이크팔레트14호.jpg",
    desc: `고민말고 팔레트 하나만 챙겨~!
    <br>많이 쓰는 컬러는 더 담아 전 컬러 동시 힛팬 가능`,
  },
{
  id: 12,
  title: "올테이크 무드 테크닉 팔레트",
  category: "아이",
  price: 11000,
  img: "./images/images-Yohan/올테이크무드테크닉팔레트.jpg",
  desc: `곰손도 금손처럼 프로페셔널하게 
  <br>올테이크 무드 테크닉 팔레트 `,
},
{
  id: 13,
  title: "스피디 스키니 브로우",
  category: "아이",
  price: 6000,
  img: "./images/images-Yohan/잉크블랙카라.jpg",
  desc: `한 올 한 올 자연스럽게 쓱쓱 그려내는
  <br>1.5mm 스키니 브로우 펜슬`,
},
{
  id: 14,
  title: "잉크 블랙 카라(AD)",
  category: "아이",
  price: 12000,
  img: "./images/images-Yohan/잉크더벨벳.jpg",
  desc: `누적 판매 90만 개 달성
  <br>후기가 인정한 잉크 블랙 카라 `,
},
{
  id: 15,
  title: "잉크 블랙 카라 (AD) #최고심콜라보",
  category: "아이",
  price: 12000,
  img: "./images/images-Yohan/최고심콜라보아이.jpg",
  desc: `무기력하고 지친 페리 덕후들을 위해 준비한
  <br>페리페라X최고심 갓생 프로젝트에 초대합니다!`,
},
{
  id: 16,
  title: "[선런칭특가] 심플레인 슬림 마스카라",
  category: "아이",
  price: 12000,
  img: "./images/images-Yohan/심플레인슬림마스카라.jpg",
  desc: `기본에 더해진 내 취향 한 겹
  <br>데일리하고 코지한 일상의 따스함을 담은 컬러무드로
  <br>당신만의 취행을 담아보세요:)`,
},
{
  id: 17,
  title: "심플레인 래쉬앰플 (속눈썹 영양제)",
  category: "아이",
  price: 14000,
  img: "./images/images-Yohan/심플레인래쉬앰플.jpg",
  desc: `붉은토끼풀꽃추출물 + 아세틸테트라펩타이드-3 결합 원료사특허성분
  <br>원료사 특허성분으로 손상된 속눈썹 튼튼케어
  <br>무엇 하나 놓치지 않는 촘촘케어`,
},
{
  id: 18,
  title: "스피디 브로우 오토 펜슬",
  category: "아이",
  price: 11000,
  img: "./images/images-Yohan/스피디브로우오토펜슬.jpeg",
  desc: `원래 내 눈썹같은 자연스러운 컬러
  <br>덧칠해도 인위적이지 않고
  <br>부드럽게 발려 자연스러운 컬러 연출 `,
},
{
  id: 19,
  title: "스피디 스키니 브로우카라",
  category: "아이",
  price: 12000,
  img: "./images/images-Yohan/스피디스키니브로우카라.jpg",
  desc: `뭉침 걱정 없이 정교하게 컬러체인지 쓱-싹
  <br>스피디 스키니 브로우카라`,
},



{
  id: 20,
  title: "[NEW] 맑게 물든 글로리 하이라이터",
  category: "하이라이터",
  price: 14000,
  img: "./images/images-Yohan/맑게물든글로리하이라이터.jpg",
  desc: `뭉침 걱정 없는 휘뚜루마뚜루 입문템
  <br> 묻어남 걱정 없이 자연스러운 영-한 광채
  <br>베이크드 타입으로 브러쉬와 찰떡궁합`,
},
{
  id: 21,
  title: "잉크 브이 하이라이터",
  category: "하이라이터",
  price: 12000,
  img: "./images/images-Yohan/잉크브이하이라이터.jpg",
  desc: `이목구비 입체감 연출에 도움을 주는 영롱 장착 플래쉬 샷!
  <br>중간 단께만 닳을 걱정 없는 1:2:1 V 비율
  <br>맑은 광이 챠르르~도는 자체 반사판 미모 연출`,
},




{
  id: 21,
  title: "잉크 브이 쉐딩",
  category: "쉐딩",
  price: 14000,
  img: "./images/images-Yohan/잉크브이쉐딩.jpg",
  desc: `뷰티어워드 1등
  <br>잉크 브이 쉐딩
  <br>가장 손이 많이가는 중간 컬러의
  <br>비율을 높혀 중간 컬러의 힛팬 현상은 NO!`,
},



{
  id: 22,
  title: "잉크 립앤아이 리무버",
  category: "클렌징",
  price: 5000,
  img: "./images/images-Yohan/잉크립앤아이리무버.jpg",
  desc: `잉크 립앤아이 리무버로
  <br>진한 메이크업도 단번에 클렌징하세요!`,
},

];
// get parent element
const sectionCenter = document.querySelector(".section-center");
const btnContainer = document.querySelector(".btn-container");
// display all items when page loads
window.addEventListener("DOMContentLoaded", function () {
  diplayMenuItems(menu);
  displayMenuButtons();
});

function diplayMenuItems(menuItems) {
  let displayMenu = menuItems.map(function (item) {
    // console.log(item);

    return `<article class="menu-item">
          <img src=${item.img} alt=${item.title} class="photo" />
          <div class="item-info">
            <header>
              <h4>${item.title}</h4>
              <h4 class="price">${item.price}원</h4>
            </header>
            <p class="item-text">
              ${item.desc}
            </p>
          </div>
        </article>`;
  });
  displayMenu = displayMenu.join("");


  sectionCenter.innerHTML = displayMenu;
}
function displayMenuButtons() {
  const categories = menu.reduce(
    function (values, item) {
      
      if (!values.includes(item.category)) {
        values.push(item.category);
      }
      console.log(values);
      return values;
  
    },
    ["전체"]
  );
  const categoryBtns = categories
    .map(function (category) {
      return `<button type="button" class="filter-btn" data-id=${category}>
          ${category}
        </button>`;
    })
    .join("");

    console.log('categoryBtns')

  btnContainer.innerHTML = categoryBtns;
  const filterBtns = btnContainer.querySelectorAll(".filter-btn");


  filterBtns.forEach(function (btn) {
    btn.addEventListener("click", function (e) {
    
      const category = e.currentTarget.dataset.id;
      console.log(e.currentTarget.dataset);
      const menuCategory = menu.filter(function (menuItem) {

        if (menuItem.category === category) {
          return menuItem;
        }
      });
      if (category === "전체") {
        diplayMenuItems(menu);
      } else {
        diplayMenuItems(menuCategory);
      }
    });
  });
}
